package my.ajax.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;

import my.ajax.domain.Member;
import my.ajax.service.MemberService;

public class SearchByIdJsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public SearchByIdJsonServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");

		PrintWriter out = response.getWriter();

		String searchId = request.getParameter("searchId");

		MemberService service = new MemberService();
		List<Member> members = service.searchById(searchId);

		String jsonResult = convertToJson(members);
		System.out.println(jsonResult);

		out.println(jsonResult);

	}

	private String convertToJson(Object object){
		
		XStream xstream = new XStream(new JsonHierarchicalStreamDriver());
		String jsonResult = xstream.toXML(object);
		
		return jsonResult;
	}
	
	
	
	
	
}
