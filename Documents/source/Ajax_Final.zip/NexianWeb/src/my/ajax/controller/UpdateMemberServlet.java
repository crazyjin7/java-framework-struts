package my.ajax.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import my.ajax.domain.Member;
import my.ajax.service.MemberService;

public class UpdateMemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UpdateMemberServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		process(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	
		process(request, response);
	}

	private void process(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		PrintWriter out = response.getWriter();
		
		//�Ķ���� ȹ��
		String id = request.getParameter("id");
		String name= request.getParameter("name");
		String nick = request.getParameter("nick");
		String email = request.getParameter("email");
		String note = request.getParameter("note");
	
		//��� ��ü ȹ��
		MemberService service = new MemberService();
		Member member = service.find(id);
		try{
			if(member != null){
				//��ü�� ����
				member.setName(name);
				member.setNick(nick);
				member.setEmail(email);
				member.setNote(note);
				
				service.updateMember(member);
			}
			out.println(true);
			
		} catch (Exception e){
			e.printStackTrace();
			out.println(false);
			
		}

	}
	
	
	
	
	

}
