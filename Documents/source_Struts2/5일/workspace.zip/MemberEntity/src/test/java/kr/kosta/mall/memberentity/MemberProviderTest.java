package kr.kosta.mall.memberentity;

/**
 *
 * @author �����
 *
 */
public class MemberProviderTest {

}
