
$(document).ready(function(){
	$('#searchId').keyup(searchById);
//	$('#searchId').bind('keyup', searchById);
});


function searchById(e){
	var url = 'SearchByIdJsonServlet';
	var id = $(e.target).val();
	
	var params = {searchId:id};
	
//	$.post(url, params, callback);
	$.getJSON(url, params, callback);
	
}


function callback(responseText, status){
	initialize();
	
//	var results = eval('(' + responseText + ')').list;
	var results = responseText.list;
	
	var ulEl = $('<ul>');
	
	for(var i=0; i<results.length; i++){
		var name = results[i].name;
		
		$('<li>').text(name).appendTo(ulEl);
		//ulEl.append($('<li>').text(name));
	}

	$('#div_result').append(ulEl);
}


function initialize(){
	$('#div_result').empty();
}













