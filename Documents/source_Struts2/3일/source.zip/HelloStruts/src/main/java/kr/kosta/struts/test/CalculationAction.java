package kr.kosta.struts.test;

public class CalculationAction {

	private int value1;
	private int value2;
	private int resultValue;
	private String calculator;

	private Calculation calculation;

	public String addition() {
		System.out.println("addition");

		resultValue = value1 + value2;
		calculator = "+";

		return "success";
	}

	public String subtraction() {
		System.out.println("subtraction");

		resultValue = value1 - value2;
		setCalculator("-");

		return "success";
	}

	public String multiplication() {
		System.out.println("multiplication");

		resultValue = value1 * value2;
		setCalculator("*");

		return "success";
	}

	public String division() {
		System.out.println("division");

		resultValue = value1 / value2;
		setCalculator("/");

		return "success";
	}

	public int getValue1() {
		return value1;
	}

	public void setValue1(int value1) {
		this.value1 = value1;
	}

	public int getValue2() {
		return value2;
	}

	public void setValue2(int value2) {
		this.value2 = value2;
	}

	public int getResultValue() {
		return resultValue;
	}

	public void setResultValue(int resultValue) {
		this.resultValue = resultValue;
	}

	public String getCalculator() {
		return calculator;
	}

	public void setCalculator(String calculator) {
		this.calculator = calculator;
	}

	public Calculation getCalculation() {
		return calculation;
	}

	public void setCalculation(Calculation calculation) {
		this.calculation = calculation;
	}

}
