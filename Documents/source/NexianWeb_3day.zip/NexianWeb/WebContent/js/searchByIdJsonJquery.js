
$(document).ready(function(){
	$('#searchId').keyup(searchById);
//	$('#searchId').bind('keyup', searchById);
});


function searchById(e){
	var url = 'SearchByIdJsonServlet';
	var id = $(e.target).val();
//	var id = e.target.value;
	
	var params = 'searchId='+id;
	
	$.post(url, params, callback);
	
}


function callback(responseText, status){
	
	alert(responseText);
	
}


