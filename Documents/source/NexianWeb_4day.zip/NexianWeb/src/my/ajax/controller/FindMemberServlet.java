package my.ajax.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import my.ajax.domain.Member;
import my.ajax.service.MemberService;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.json.JsonHierarchicalStreamDriver;

public class FindMemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public FindMemberServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		PrintWriter out = response.getWriter();
		
		String id = request.getParameter("id");
		
		MemberService service = new MemberService();
		Member member = service.find(id);
		
		String jsonResult = convertToJson(member);
		System.out.println(jsonResult);
		
		out.println(jsonResult);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
	}

	
	private String convertToJson(Object object){
		
		XStream xstream = new XStream(new JsonHierarchicalStreamDriver());
		xstream.alias("member", Member.class);
		String jsonResult = xstream.toXML(object);
		
		return jsonResult;
	}

}
